#pragma once // Thêm dòng này nếu chưa có

#include <SDL.h>
#include <SDL_ttf.h>
#include <string>

// Các hàm đã có của bạn
SDL_Texture* loadTexture(const std::string& path, SDL_Renderer* renderer);
void drawText(SDL_Renderer* renderer, TTF_Font* font, const std::string& text, SDL_Rect rect);
void drawButton(SDL_Renderer* renderer, TTF_Font* font, SDL_Rect rect, const std::string& label);
void render(SDL_Renderer* renderer, TTF_Font* font, SDL_Rect playBtn, SDL_Rect exitBtn, SDL_Rect helpBtn); // Thêm helpBtn
void Welcome(SDL_Window* window, SDL_Renderer* renderer, TTF_Font* font);

// Khai báo hàm mới cho màn hình hướng dẫn
void showInstructionsScreen(SDL_Renderer* renderer, TTF_Font* font);
