#ifndef ENDGAME_H
#define ENDGAME_H

#include <SDL.h>
#include <SDL_ttf.h>
#include <string>

class Board;
void showEndGame(Board& board,const std::string& winnerText, int score1, int score2, bool& running);

#endif // ENDGAME_H
