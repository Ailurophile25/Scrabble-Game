#pragma once
#include <string>
#include <unordered_map>

class TrieNode {
public:
    bool isEnd;
    std::unordered_map<char, TrieNode*> children;

    TrieNode() : isEnd(false) {}
    ~TrieNode() {
        for (auto& p : children) delete p.second;
    }
};

class Trie {
private:
    TrieNode* root;

public:
    Trie();
    ~Trie();
    void insert(const std::string& word);
    bool search(const std::string& word) const;
    bool startsWith(const std::string& prefix) const;
};
