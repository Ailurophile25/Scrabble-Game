#pragma once
#include <vector>
#include <string>
#include "Tile.h"
#include "Bag.h"
using namespace std;

class Player {
private:
    string name;
    vector<Tile> hand;
    int score;
    float timeRemaining;

public:
    Player(string name);
    void drawTiles(Bag& bag);                 // Rút cho đủ 7 chữ
    void addScore(int points);                // Cộng điểm
    string getName() const;
    int getScore() const;

    //Hàm quản lý thời gian
    float getTimeRemaining() const;
    void decreaseTime(float seconds);


    // Trả về danh sách tile trên tay (2 phiên bản)
    const vector<Tile>& getHand() const;      // Chỉ đọc (UI hiển thị)
    vector<Tile>& getHand();                  // Chỉnh sửa (kéo tile, remove tile thủ công)

    void removeTile(char letter);             // Xoá 1 tile khỏi tay
    bool hasTile(char letter) const;          // Kiểm tra có tile không
    void displayTiles() const;
    void returnTile(const Tile& tile);

};
