// EndScreen.h
#ifndef ENDSCREEN_H
#define ENDSCREEN_H

#include <SDL.h>
#include <SDL_ttf.h>
#include <string>

// Hàm để hiển thị màn hình kết thúc
void showEndScreen(SDL_Renderer* renderer, TTF_Font* font, const std::string& winnerText, int score1, int score2);

#endif // ENDSCREEN_H
