// GameLogic.h

#pragma once
#include "Board.h"
#include "Bag.h"
#include "Player.h"
#include "Dictionary.h"
#include <deque>
#include <SDL.h> // <-- THÊM THƯ VIỆN SDL

class GameLogic {
private:
    int greedyStopThreshold = 30;
    Board board;
    Bag bag;
    Dictionary dict;
    Player player1, player2;
    Player* currentPlayer;
    std::vector<std::pair<int,int>> placedTiles;
    std::deque<std::string> lastWords;

    Uint32 turnStartTime; //  Lưu thời điểm bắt đầu lượt (ms)

    // ++ TÍNH NĂNG HINT MỚI ++
    std::string hintSuggestion; // Chuỗi gợi ý để hiển thị, ví dụ: "Đặt 'A' tại (7,8)"

    // Hàm trợ giúp
    void switchToNextPlayer(); //
    std::string formatTime(float seconds); //

     // ++ TÍNH NĂNG HINT MỚI ++
    void findHint(); // Hàm tìm gợi ý

    int getLetterScore(char letter) const;

    // Hàm kiểm tra một ô có phải anchor (điểm neo) không
    bool isAnchor(int row, int col) const;

    // Hàm tính điểm cho một từ (có thể dùng trong hint và khi đặt từ)
    int calculateScore(int startRow, int startCol,
                       const std::string& word,
                       const std::string& direction,
                       const std::vector<std::pair<int, int>>& placed) const;


public:
    GameLogic(const std::string& dictFile);

    bool placeTileUI(int row, int col, Tile tile);
    bool confirmWord();
    void nextTurn();
    Player* getCurrentPlayer();
    Board& getBoard();
    bool isGameOver();
    void run(SDL_Window* window, SDL_Renderer* renderer, TTF_Font* font);
};
