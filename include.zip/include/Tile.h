#pragma once
#include <string>
using namespace std;

class Tile {
public:
    char letter;   // Ký tự A-Z
    int points;    // Số điểm tương ứng (vd: A = 1, Q = 10)

    Tile(char l, int p);
    Tile(); // constructor mặc định nếu cần
};

