#pragma once
#include <string>
#include "Board.h"
#include "Player.h"
using namespace std;

class UserInterface {
public:
    void displayBoard(const Board& board) const;
    string getWordInput(const Player& player) const;
    void showMessage(const string& message) const;
};


