#pragma once
#include <SDL.h>
#include <SDL_ttf.h>
#include <string>
#include <vector>
#include "Square.h"
#include "Tile.h"
#include "Player.h"
#include "Dictionary.h"
#include <set>
#include <unordered_map>
#include <string>

// THAY ĐỔI: Thêm các hằng số cho layout
const int TILE_SIZE = 45; // Tăng kích thước tile một chút cho đẹp hơn
const int BOARD_SIZE = 15;
const int BOARD_OFFSET_X = 50; // Khoảng cách từ lề trái màn hình đến bàn cờ
const int BOARD_OFFSET_Y = 20; // Khoảng cách từ lề trên màn hình đến bàn cờ
const int BOARD_WIDTH_PIXELS = BOARD_SIZE * TILE_SIZE;
const int BOARD_HEIGHT_PIXELS = BOARD_SIZE * TILE_SIZE;

enum CellType { NORMAL, DOUBLE_LETTER, TRIPLE_LETTER, DOUBLE_WORD, TRIPLE_WORD, CENTER };

class Board {
private:
    static const int SIZE = BOARD_SIZE;
    std::vector<std::vector<Square>> grid;
    CellType boardMap[15][15];

    SDL_Renderer* renderer;
    TTF_Font* font;

    bool firstMove;
    int selectedRow, selectedCol;

    SDL_Rect resignBtn, skipBtn, swapBtn, submitBtn, undoBtn, hintBtn;

public:
    Board();
    ~Board();

    std::unordered_map<char, SDL_Texture*> letterTextures;
    void loadLetterTextures(SDL_Renderer* renderer);
    void freeLetterTextures();
    SDL_Texture* getLetterTexture(char c) const;

    void init(SDL_Renderer* renderer_, TTF_Font* font_);
    void initBoardMap(int screenWidth, int screenHeight); // Thêm tham số kích thước màn hình

    SDL_Renderer* getRenderer() const { return renderer; }
    TTF_Font* getFont() const { return font; }

    void handleEvent(SDL_Event& event);
    void render(SDL_Renderer* renderer, const std::vector<std::pair<int,int>>& placedTiles);
    std::set<std::pair<int, int>> committedTiles;

    // ... các hàm khác giữ nguyên ...
    Square& getSquare(int row, int col);
    const Square& getSquare(int row, int col) const;
    bool isEmpty(int row, int col) const;
    void placeTile(int row, int col, Tile tile);
    void testPlaceTile(int row, int col, Tile tile);
    void removeTileAt(int row, int col);
    bool validatePlacement(const std::vector<std::pair<int,int>>& placedTiles) const;
    std::string collectWordHorizontal(int row, int col) const;
    std::string collectWordVertical(int row, int col) const;
    std::string getCurrentWord(const std::vector<std::pair<int, int>>& placedTiles) const;
    int commitWord(std::vector<std::pair<int,int>>& placedTiles, Player& player, Dictionary& dict);
    std::vector<std::tuple<int, int, Tile>> undoStack;
    bool undo(Player& player);
    void clearUndo();
    int getSelectedRow() const { return selectedRow; }
    int getSelectedCol() const { return selectedCol; }
    const Tile* getTileAt(int row, int col) const;
    void drawText(SDL_Renderer* renderer, TTF_Font* font, const std::string& text, SDL_Rect rect);
    void drawButton(SDL_Renderer* renderer, TTF_Font* font, SDL_Rect rect, const std::string& label);
    const SDL_Rect& getResignBtn() const;
    const SDL_Rect& getSubmitBtn() const;
    const SDL_Rect& getUndoBtn() const;
    const SDL_Rect& getSwapBtn() const;
    const SDL_Rect& getSkipBtn() const;
    const SDL_Rect& getHintBtn() const;
};
