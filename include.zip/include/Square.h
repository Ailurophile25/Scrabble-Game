#pragma once
#include "Tile.h"
#include <optional>

enum class Bonus {
    NONE,
    DOUBLE_LETTER,
    TRIPLE_LETTER,
    DOUBLE_WORD,
    TRIPLE_WORD
};

class Square {
private:
    Tile* tile;
    Bonus bonus;

public:
    Square();
    Square(Bonus b);
    ~Square(); // Thêm hàm hủy

    bool isOccupied() const;
    void placeTile(const Tile& t); // Sửa lại để an toàn hơn
    const Tile* getTile() const;   // Sửa kiểu trả về
    Bonus getBonus() const;
    void removeTile();
};
