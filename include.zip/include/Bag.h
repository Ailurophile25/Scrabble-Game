
#include <algorithm>
#pragma once
#include <vector>
#include <random>
#include "Tile.h"
using namespace std;

class Bag {
private:
    vector<Tile> tiles;

public:
    Bag(); // Khởi tạo túi chữ cái
    Tile drawTile();              // Rút ngẫu nhiên 1 tile
    void putBackTile(Tile tile); // Trả tile lại túi
    bool isEmpty() const;        // Kiểm tra túi có rỗng không
};


