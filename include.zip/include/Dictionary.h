#pragma once
#include <string>
#include "Trie.h"

class Dictionary {
private:
    Trie trie;

public:
    Dictionary(const std::string& filename);
    bool isValidWord(const std::string& word) const;
    bool startsWith(const std::string& prefix) const;
};
