#include "Trie.h"

Trie::Trie() {
    root = new TrieNode();
}

Trie::~Trie() {
    delete root;
}

void Trie::insert(const std::string& word) {
    TrieNode* node = root;
    for (char ch : word) {
        if (!node->children[ch]) {
            node->children[ch] = new TrieNode();
        }
        node = node->children[ch];
    }
    node->isEnd = true;
}

bool Trie::search(const std::string& word) const {
    TrieNode* node = root;
    for (char ch : word) {
        if (!node->children.count(ch)) return false;
        node = node->children.at(ch);
    }
    return node->isEnd;
}

bool Trie::startsWith(const std::string& prefix) const {
    TrieNode* node = root;
    for (char ch : prefix) {
        if (!node->children.count(ch)) return false;
        node = node->children.at(ch);
    }
    return true;
}
