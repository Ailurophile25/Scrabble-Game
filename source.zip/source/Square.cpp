#include "Square.h"

Square::Square() : tile(nullptr), bonus(Bonus::NONE) {}

Square::Square(Bonus b) : tile(nullptr), bonus(b) {}

// Hàm hủy sẽ tự động giải phóng bộ nhớ của Tile nếu nó tồn tại
Square::~Square() {
    delete tile;
}

bool Square::isOccupied() const {
    return tile != nullptr;
}

// Hàm này sẽ xóa tile cũ (nếu có) trước khi đặt tile mới
void Square::placeTile(const Tile& t) {
    delete tile; // Xóa tile cũ để tránh rò rỉ bộ nhớ
    tile = new Tile(t);
}

const Tile* Square::getTile() const {
    return tile;
}

Bonus Square::getBonus() const {
    return bonus;
}

// Hàm removeTile bây giờ sẽ xóa an toàn quân cờ khỏi ô
void Square::removeTile() {
    delete tile;
    tile = nullptr;
}
