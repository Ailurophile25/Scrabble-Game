#include "Player.h"
#include <iostream>
using namespace std;

Player::Player(string name) : name(name), score(0), timeRemaining(500.0f) {}

void Player::drawTiles(Bag& bag) {
    // Rút như bình thường
    while (hand.size() < 7 && !bag.isEmpty()) {
        hand.push_back(bag.drawTile());
    }

    // Kiểm tra nếu không có nguyên âm thì thay thế 1 quân thành nguyên âm
    auto isVowel = [](char c) {
        c = toupper(c);
        return (c=='A' || c=='E' || c=='I' || c=='O' || c=='U');
    };

    bool hasVowel = false;
    for (auto &tile : hand) {
        if (isVowel(tile.letter)) {
            hasVowel = true;
            break;
        }
    }

    if (!hasVowel && !bag.isEmpty()) {
        // Trả quân cuối cùng về túi và rút nguyên âm
        Tile last = hand.back();
        hand.pop_back();
        bag.putBackTile(last);

        // Tìm nguyên âm trong túi
        std::vector<Tile> temp;
        Tile vowelTile;
        bool found = false;

        while (!bag.isEmpty()) {
            Tile t = bag.drawTile();
            if (!found && isVowel(t.letter)) {
                vowelTile = t;
                found = true;
                break;
            }
            temp.push_back(t);
        }

        // Trả các quân đã rút tạm thời về túi
        for (auto &t : temp) bag.putBackTile(t);

        if (found) {
            hand.push_back(vowelTile);
        }
    }
}


void Player::addScore(int points) {
    score += points;
}

string Player::getName() const {
    return name;
}

int Player::getScore() const {
    return score;
}

// Lấy thời gian còn lại
float Player::getTimeRemaining() const {
    return timeRemaining;
}

// Giảm thời gian
void Player::decreaseTime(float seconds) {
    timeRemaining -= seconds;
    if (timeRemaining < 0) {
        timeRemaining = 0;
    }
}

const vector<Tile>& Player::getHand() const {
    return hand;
}

vector<Tile>& Player::getHand() {     // ✅ Non-const version cho phép thao tác trực tiếp
    return hand;
}

void Player::removeTile(char letter) {
    for (auto it = hand.begin(); it != hand.end(); ++it) {
        if (it->letter == letter) {
            hand.erase(it);
            break;
        }
    }
}


bool Player::hasTile(char letter) const {
    for (const auto& t : hand) {
        if (t.letter == letter) return true;
    }
    return false;
}

void Player::displayTiles() const {
    for (const auto& t : hand) {
        cout << t.letter << "(" << t.points << ") ";
    }
    cout << endl;
}

void Player::returnTile(const Tile& tile) {
    hand.push_back(tile);
}
