#include "Dictionary.h"
#include <fstream>
#include <algorithm>

Dictionary::Dictionary(const std::string& filename) {
    std::ifstream file(filename);
    std::string word;
    while (file >> word) {
        std::transform(word.begin(), word.end(), word.begin(), ::toupper);
        trie.insert(word);
    }
}

bool Dictionary::isValidWord(const std::string& word) const {
    return trie.search(word);
}

bool Dictionary::startsWith(const std::string& prefix) const {
    return trie.startsWith(prefix);
}
