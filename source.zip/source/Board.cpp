// ============================================================================
// Board.cpp
// Vai trò:
//   - Quản lý bàn cờ 15x15 (ô thưởng, ô trung tâm, trạng thái quân).
//   - Tải texture chữ cái (A–Z, blank), vẽ bàn, vẽ nút UI, vẽ chữ.
//   - Xử lý chọn ô, đặt/hoàn tác quân, kiểm tra hợp lệ, chấm điểm & commit từ.
// Thuật toán chính:
//   1) initBoardMap(): set bonus map (DL, TL, DW, TW, CENTER) + bố trí nút UI.
//   2) render(): vẽ nền/viền/nhãn bonus, vẽ quân mới đặt & quân đã chốt, vẽ nút.
//   3) commitWord():
//        - Kiểm tra hợp lệ (hàng/cột, nối với quân cũ, lượt đầu chạm CENTER).
//        - Tìm từ chính + từ phụ vuông góc, validate dictionary.
//        - Tính điểm (letter/word multiplier chỉ tính cho quân mới đặt), cộng điểm.
//   4) undo(): trả lại quân vừa đặt gần nhất, phục hồi tay người chơi.
// Lưu ý hiệu năng: cache texture chữ cái sẵn; text TTF dùng tạm thời nên nhớ free.
// ============================================================================

#include "Board.h"
#include "Start.h"

#include <algorithm>
#include <iostream>
#include <SDL_image.h>

using namespace std;

Board::Board() : firstMove(true), selectedRow(-1), selectedCol(-1) {
    // Khởi tạo lưới 15x15 ô Square rỗng
    grid.resize(SIZE, vector<Square>(SIZE));
}

Board::~Board() {
    // Giải phóng toàn bộ texture chữ đã nạp
    freeLetterTextures();
}

// -----------------------------------------------------------------------------
// Tải texture cho A..Z và quân blank ('?')
// - Mục đích: khi render quân, ưu tiên dùng ảnh PNG để sắc nét/đồng nhất.
// -----------------------------------------------------------------------------
void Board::loadLetterTextures(SDL_Renderer* renderer) {
    const std::string letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    for (char c : letters) {
        std::string path = "PNGs/";
        path.push_back(c);
        path += ".png";

        SDL_Surface* surf = IMG_Load(path.c_str());
        if (!surf) {
            std::cerr << "IMG_Load failed for " << path << ": " << IMG_GetError() << std::endl;
            continue;
        }
        SDL_Texture* tex = SDL_CreateTextureFromSurface(renderer, surf);
        SDL_FreeSurface(surf);
        if (!tex) {
            std::cerr << "CreateTexture failed for " << path << ": " << SDL_GetError() << std::endl;
            continue;
        }
        letterTextures[c] = tex;
    }

    // Quân trắng/blank (ký hiệu '?')
    std::string blankPath = "PNGs/blank.png";
    SDL_Surface* blankSurf = IMG_Load(blankPath.c_str());
    if (blankSurf) {
        SDL_Texture* blankTex = SDL_CreateTextureFromSurface(renderer, blankSurf);
        SDL_FreeSurface(blankSurf);
        if (blankTex) letterTextures['?'] = blankTex;
    }
}

// -----------------------------------------------------------------------------
// Giải phóng texture chữ
// -----------------------------------------------------------------------------
void Board::freeLetterTextures() {
    for (auto &p : letterTextures) {
        if (p.second) SDL_DestroyTexture(p.second);
    }
    letterTextures.clear();
}

// -----------------------------------------------------------------------------
// Trả về texture chữ đã nạp; fallback về blank nếu không có
// -----------------------------------------------------------------------------
SDL_Texture* Board::getLetterTexture(char c) const {
    char up = static_cast<char>(toupper(static_cast<unsigned char>(c)));
    auto it = letterTextures.find(up);
    if (it != letterTextures.end()) return it->second;
    auto it2 = letterTextures.find('?');
    if (it2 != letterTextures.end()) return it2->second;
    return nullptr;
}

// -----------------------------------------------------------------------------
// init: gán renderer/font, tính layout bàn & nút, nạp texture chữ
// -----------------------------------------------------------------------------
void Board::init(SDL_Renderer* renderer_, TTF_Font* font_) {
    renderer = renderer_;
    font = font_;

    int windowWidth, windowHeight;
    SDL_GetRendererOutputSize(renderer, &windowWidth, &windowHeight);
    initBoardMap(windowWidth, windowHeight);

    loadLetterTextures(renderer_);
}

// -----------------------------------------------------------------------------
// initBoardMap: thiết lập bản đồ thưởng & bố trí cụm nút UI (2x3) thấp gần đáy
// -----------------------------------------------------------------------------
void Board::initBoardMap(int screenWidth, int screenHeight) {
    // 1) Reset toàn bộ ô -> NORMAL
    for (int r = 0; r < SIZE; ++r)
        for (int c = 0; c < SIZE; ++c)
            boardMap[r][c] = NORMAL;

    // 2) Đặt ô trung tâm & các ô thưởng chuẩn Scrabble
    boardMap[7][7] = CENTER;

    int tripleWord[][2] = {{0,0},{0,7},{0,14},{7,0},{7,14},{14,0},{14,7},{14,14}};
    for (auto& pos : tripleWord) boardMap[pos[0]][pos[1]] = TRIPLE_WORD;

    int doubleWord[][2] = {
        {1,1},{2,2},{3,3},{4,4},{13,13},{12,12},{11,11},{10,10},
        {1,13},{2,12},{3,11},{4,10},{13,1},{12,2},{11,3},{10,4}
    };
    for (auto& pos : doubleWord) boardMap[pos[0]][pos[1]] = DOUBLE_WORD;

    int tripleLetter[][2] = {
        {1,5},{5,1},{5,5},{5,9},{9,5},{9,9},{13,9},{9,13},{1,9},{13,5},{5,13},{9,1}
    };
    for (auto& pos : tripleLetter) boardMap[pos[0]][pos[1]] = TRIPLE_LETTER;

    int doubleLetter[][2] = {
        {0,3},{0,11},{2,6},{2,8},{3,0},{3,7},{3,14},{6,2},{6,6},{6,8},{6,12},
        {7,3},{7,11},{8,2},{8,6},{8,8},{8,12},{11,0},{11,7},{11,14},{12,6},{12,8},
        {14,3},{14,11}
    };
    for (auto& pos : doubleLetter) boardMap[pos[0]][pos[1]] = DOUBLE_LETTER;

    // 3) Bố trí cụm nút bên phải, 2 hàng x 3 cột, gần đáy màn hình
    int rightPanelX = BOARD_OFFSET_X + BOARD_WIDTH_PIXELS + 50;
    int buttonAreaY = screenHeight - 180; // đẩy xuống thấp cho thoáng

    int btnW = 120, btnH = 50;
    int spacingX = 20, spacingY = 20;

    submitBtn = { rightPanelX + 0 * (btnW + spacingX), buttonAreaY + 0 * (btnH + spacingY), btnW, btnH };
    skipBtn   = { rightPanelX + 1 * (btnW + spacingX), buttonAreaY + 0 * (btnH + spacingY), btnW, btnH };
    swapBtn   = { rightPanelX + 2 * (btnW + spacingX), buttonAreaY + 0 * (btnH + spacingY), btnW, btnH };

    hintBtn   = { rightPanelX + 0 * (btnW + spacingX), buttonAreaY + 1 * (btnH + spacingY), btnW, btnH };
    undoBtn   = { rightPanelX + 1 * (btnW + spacingX), buttonAreaY + 1 * (btnH + spacingY), btnW, btnH };
    resignBtn = { rightPanelX + 2 * (btnW + spacingX), buttonAreaY + 1 * (btnH + spacingY), btnW, btnH };
}

// -----------------------------------------------------------------------------
// handleEvent: chọn ô khi click chuột trái (để debug/feedback vị trí)
// -----------------------------------------------------------------------------
void Board::handleEvent(SDL_Event& event) {
    if (event.type == SDL_MOUSEBUTTONDOWN && event.button.button == SDL_BUTTON_LEFT) {
        int mx = event.button.x, my = event.button.y;
        int col = (mx - BOARD_OFFSET_X) / TILE_SIZE;
        int row = (my - BOARD_OFFSET_Y) / TILE_SIZE;

        if (row >= 0 && row < SIZE && col >= 0 && col < SIZE) {
            selectedRow = row;
            selectedCol = col;
            cout << "Selected: (" << row << "," << col << ")\n";
        }
    }
}

// -----------------------------------------------------------------------------
// render: vẽ toàn bộ bàn + quân + nhãn bonus + các nút UI
// - Ô vừa đặt trong lượt: đỏ gạch (highlight).
// - Ô đã commit: vàng nhạt.
// - Ô trống: tô màu theo bonus + vẽ nhãn (DW, TW, DL, TL, X).
// -----------------------------------------------------------------------------
void Board::render(SDL_Renderer* renderer, const std::vector<std::pair<int,int>>& placedTiles) {
    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) {
            SDL_Rect rect = {
                BOARD_OFFSET_X + c * TILE_SIZE,
                BOARD_OFFSET_Y + r * TILE_SIZE,
                TILE_SIZE, TILE_SIZE
            };

            // Kiểm tra ô có nằm trong danh sách vừa đặt không
            bool isNewTile = (std::find(placedTiles.begin(), placedTiles.end(), std::make_pair(r, c)) != placedTiles.end());

            // Màu nền theo trạng thái
            if (isNewTile) {
                SDL_SetRenderDrawColor(renderer, 187, 73, 76, 255);          // đỏ gạch cho chữ mới
            } else if (committedTiles.count({r, c})) {
                SDL_SetRenderDrawColor(renderer, 255, 230, 128, 255);        // vàng nhạt cho chữ đã commit
            } else {
                switch (boardMap[r][c]) {
                    case NORMAL:        SDL_SetRenderDrawColor(renderer, 240, 240, 240, 255); break;
                    case DOUBLE_LETTER: SDL_SetRenderDrawColor(renderer, 173, 216, 230, 255); break;
                    case TRIPLE_LETTER: SDL_SetRenderDrawColor(renderer, 216, 238, 93, 223);  break;
                    case DOUBLE_WORD:   SDL_SetRenderDrawColor(renderer, 255, 182, 193, 255); break;
                    case TRIPLE_WORD:   SDL_SetRenderDrawColor(renderer, 250, 188, 98, 255);  break;
                    case CENTER:        SDL_SetRenderDrawColor(renderer, 255, 182, 193, 255); break;
                    default:            SDL_SetRenderDrawColor(renderer, 240, 240, 240, 255); break;
                }
            }

            // Vẽ nền + viền ô
            SDL_RenderFillRect(renderer, &rect);
            SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
            SDL_RenderDrawRect(renderer, &rect);

            // Nếu ô không có quân: vẽ nhãn bonus
            const Tile* currentTile = getTileAt(r, c);
            string label;
            switch (boardMap[r][c]) {
                case TRIPLE_WORD:   label = "TW"; break;
                case DOUBLE_WORD:   label = "DW"; break;
                case DOUBLE_LETTER: label = "DL"; break;
                case TRIPLE_LETTER: label = "TL"; break;
                case CENTER:        label = "X";  break;
                default: break;
            }
            if (!label.empty() && !currentTile) {
                drawText(renderer, font, label, rect);
            }

            // Nếu có quân ở ô -> vẽ texture chữ (ưu tiên PNG), fallback TTF
            if (currentTile) {
                char ch = currentTile->letter;
                SDL_Texture* letterTex = getLetterTexture(ch);
                if (letterTex) {
                    SDL_Rect dst = { rect.x + 2, rect.y + 2, rect.w - 4, rect.h - 4 };
                    SDL_RenderCopy(renderer, letterTex, NULL, &dst);
                } else {
                    SDL_Color tileColor = { 0, 0, 0, 255 };
                    std::string letter(1, ch);
                    SDL_Surface* surf = TTF_RenderText_Blended(font, letter.c_str(), tileColor);
                    if (surf) {
                        SDL_Texture* tex = SDL_CreateTextureFromSurface(renderer, surf);
                        int w, h; SDL_QueryTexture(tex, NULL, NULL, &w, &h);
                        SDL_Rect dst = { rect.x + (TILE_SIZE - w) / 2, rect.y + (TILE_SIZE - h) / 2, w, h };
                        SDL_RenderCopy(renderer, tex, NULL, &dst);
                        SDL_FreeSurface(surf);
                        SDL_DestroyTexture(tex);
                    }
                }
            }
        }
    }

    // Vẽ cụm nút điều khiển
    drawButton(renderer, font, resignBtn, "Resign");
    drawButton(renderer, font, skipBtn,   "Skip");
    drawButton(renderer, font, swapBtn,   "Swap");
    drawButton(renderer, font, submitBtn, "Submit");
    drawButton(renderer, font, undoBtn,   "Undo");
    drawButton(renderer, font, hintBtn,   "Hint");
}

// -----------------------------------------------------------------------------
// commitWord: xác thực bố cục + chấm điểm + cập nhật trạng thái
// - Kiểm tra: lượt đầu phải chạm CENTER; cùng hàng/cột; nối với quân cũ.
// - Xác định từ chính theo hướng đặt + từ phụ vuông góc tại từng quân mới.
// - Tính điểm: letter/word multiplier chỉ áp cho ô có quân mới đặt.
// -----------------------------------------------------------------------------
int Board::commitWord(vector<pair<int,int>>& placedTiles, Player& player, Dictionary& dict) {
    if (!validatePlacement(placedTiles)) return -1;
    if (placedTiles.empty()) return -1;

    // Đảm bảo thứ tự để tính từ đầu mút chính xác
    std::sort(placedTiles.begin(), placedTiles.end());

    // Hàm nội bộ: lấy từ (liên tục) đi qua (row,col) theo 1 hướng và tính điểm
    auto scoreWord = [&](int row, int col, bool horizontal) -> std::pair<std::string,int> {
        int r = row, c = col;
        int wordScore = 0;
        int wordMultiplier = 1;
        std::string wordStr;

        // Dời về đầu từ (trái hoặc trên) trước khi quét
        if (horizontal) {
            while (c > 0 && getTileAt(r, c - 1)) c--;
        } else {
            while (r > 0 && getTileAt(r - 1, c)) r--;
        }

        // Quét tới cuối từ; cộng điểm + áp multiplier cho quân mới
        while (r < SIZE && c < SIZE && getTileAt(r, c)) {
            const Tile* t = getTileAt(r, c);
            char ch = t->letter;
            wordStr.push_back(ch);

            // Điểm chữ (giống GameLogic::getLetterScore)
            int letterScore;
            if (ch=='Q'||ch=='Z') letterScore = 10;
            else if (ch=='J'||ch=='X') letterScore = 8;
            else if (ch=='K') letterScore = 5;
            else if (ch=='F'||ch=='H'||ch=='V'||ch=='W'||ch=='Y') letterScore = 4;
            else if (ch=='B'||ch=='C'||ch=='M'||ch=='P') letterScore = 3;
            else if (ch=='D'||ch=='G') letterScore = 2;
            else letterScore = 1;

            bool isNew = std::find(placedTiles.begin(), placedTiles.end(), std::make_pair(r, c)) != placedTiles.end();
            if (isNew) {
                // Lượt đầu vẫn tính bonus như thường (đã bỏ điều kiện firstMove)
                switch (boardMap[r][c]) {
                    case DOUBLE_LETTER: letterScore *= 2; break;
                    case TRIPLE_LETTER: letterScore *= 3; break;
                    case DOUBLE_WORD:   wordMultiplier *= 2; break;
                    case TRIPLE_WORD:   wordMultiplier *= 3; break;
                    default: break;
                }
            }

            wordScore += letterScore;
            if (horizontal) c++; else r++;
        }

        if (wordStr.length() < 2) return {"", 0};

        if (!dict.isValidWord(wordStr)) {
            cout << "Invalid word in dictionary: " << wordStr << endl;
            return {"", -1};
        }

        return { wordStr, wordScore * wordMultiplier };
    };

    // Xác định hướng đặt chính (cùng hàng hay cùng cột)
    bool sameRow = std::all_of(placedTiles.begin(), placedTiles.end(),
        [&](auto& p){ return p.first == placedTiles[0].first; });

    int totalScore = 0;
    std::vector<std::pair<std::string, int>> validWordsScored;

    // 1) Từ chính (hướng theo nhóm đặt)
    if (sameRow) {
        auto [w, sc] = scoreWord(placedTiles[0].first, placedTiles[0].second, true);
        if (sc < 0) return -1;
        if (sc > 0) validWordsScored.push_back({ w, sc });
    } else {
        auto [w, sc] = scoreWord(placedTiles[0].first, placedTiles[0].second, false);
        if (sc < 0) return -1;
        if (sc > 0) validWordsScored.push_back({ w, sc });
    }

    // 2) Các từ phụ vuông góc đi qua từng quân mới đặt
    for (auto& pos : placedTiles) {
        if (sameRow) {
            auto [w, sc] = scoreWord(pos.first, pos.second, false);
            if (sc < 0) return -1;
            if (sc > 0) validWordsScored.push_back({ w, sc });
        } else {
            auto [w, sc] = scoreWord(pos.first, pos.second, true);
            if (sc < 0) return -1;
            if (sc > 0) validWordsScored.push_back({ w, sc });
        }
    }

    // 3) Cộng điểm & log
    for (const auto& p : validWordsScored) {
        totalScore += p.second;
        cout << "Word: " << p.first << ", Score: " << p.second << endl;
    }
    cout << "TOTAL SCORE: " << totalScore << endl;

    player.addScore(totalScore);

    // 4) Chuyển toàn bộ quân vừa đặt thành committed
    for (auto& p : placedTiles) committedTiles.insert(p);
    placedTiles.clear();
    firstMove = false;
    undoStack.clear();

    return totalScore;
}

// -----------------------------------------------------------------------------
// Vẽ text giữa rect (dùng nhanh cho nhãn bonus/nút UI)
// -----------------------------------------------------------------------------
void Board::drawText(SDL_Renderer* renderer, TTF_Font* font, const std::string& text, SDL_Rect rect) {
    SDL_Color color = { 0, 0, 0, 255 };
    SDL_Surface* surface = TTF_RenderText_Solid(font, text.c_str(), color);
    if (!surface) return;

    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
    if (!texture) {
        SDL_FreeSurface(surface);
        return;
    }

    int text_width = surface->w;
    int text_height = surface->h;
    SDL_Rect dst = {
        rect.x + (rect.w - text_width) / 2,
        rect.y + (rect.h - text_height) / 2,
        text_width,
        text_height
    };

    SDL_RenderCopy(renderer, texture, NULL, &dst);
    SDL_FreeSurface(surface);
    SDL_DestroyTexture(texture);
}

// -----------------------------------------------------------------------------
// Vẽ 1 nút chữ nhật + nhãn ở giữa
// -----------------------------------------------------------------------------
void Board::drawButton(SDL_Renderer* renderer, TTF_Font* font, SDL_Rect rect, const std::string& label) {
    SDL_SetRenderDrawColor(renderer, 200, 200, 200, 255);
    SDL_RenderFillRect(renderer, &rect);
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderDrawRect(renderer, &rect);
    drawText(renderer, font, label, rect);
}

// -----------------------------------------------------------------------------
// Trạng thái/điều khiển ô & undo
// -----------------------------------------------------------------------------
bool Board::isEmpty(int row, int col) const {
    return !grid[row][col].isOccupied();
}

void Board::placeTile(int row, int col, Tile tile) {
    // Lưu vào undoStack để có thể hoàn tác
    undoStack.push_back({ row, col, tile });
    grid[row][col].placeTile(tile);
}

void Board::testPlaceTile(int row, int col, Tile tile) {
    grid[row][col].placeTile(tile);
}

bool Board::validatePlacement(const std::vector<std::pair<int,int>>& placedTiles) const {
    if (placedTiles.empty()) return false;

    // Lượt đầu: bắt buộc phải chạm CENTER
    if (firstMove) {
        bool hasCenter = false;
        for (auto& pos : placedTiles)
            if (pos.first == 7 && pos.second == 7)
                hasCenter = true;
        if (!hasCenter) return false;
    }

    // Cùng hàng hoặc cùng cột
    bool sameRow = std::all_of(placedTiles.begin(), placedTiles.end(),
        [&](auto& p){ return p.first == placedTiles[0].first; });
    bool sameCol = std::all_of(placedTiles.begin(), placedTiles.end(),
        [&](auto& p){ return p.second == placedTiles[0].second; });
    if (!sameRow && !sameCol) return false;

    // Từ đặt phải nối với quân cũ (trừ lượt đầu)
    if (!firstMove) {
        bool connected = false;
        for (auto& p : placedTiles) {
            int r = p.first, c = p.second;
            std::vector<std::pair<int,int>> adj = {{r-1,c},{r+1,c},{r,c-1},{r,c+1}};
            for (auto& a : adj) {
                int ar = a.first, ac = a.second;
                if (ar >= 0 && ar < SIZE && ac >= 0 && ac < SIZE) {
                    bool isPartOfNewTiles = std::find(placedTiles.begin(), placedTiles.end(), std::make_pair(ar, ac)) != placedTiles.end();
                    if (getTileAt(ar, ac) && !isPartOfNewTiles) {
                        connected = true;
                        break;
                    }
                }
            }
            if (connected) break;
        }
        if (!connected) return false;
    }
    return true;
}

bool Board::undo(Player& player) {
    if (undoStack.empty()) return false;

    auto [row, col, tile] = undoStack.back();
    undoStack.pop_back();

    grid[row][col].removeTile();
    player.returnTile(tile);
    return true;
}

void Board::clearUndo() {
    undoStack.clear();
}

// -----------------------------------------------------------------------------
// Truy cập nhanh quân tại ô & thao tác xóa
// -----------------------------------------------------------------------------
const Tile* Board::getTileAt(int row, int col) const {
    if (row >= 0 && row < SIZE && col >= 0 && col < SIZE)
        return grid[row][col].getTile();
    return nullptr;
}

void Board::removeTileAt(int row, int col) {
    if (row >= 0 && row < SIZE && col >= 0 && col < SIZE)
        grid[row][col].removeTile();
}

// -----------------------------------------------------------------------------
// Gom chuỗi theo phương ngang/dọc đi qua (row,col)
// -----------------------------------------------------------------------------
std::string Board::collectWordHorizontal(int row, int col) const {
    std::string word;
    int c = col;
    while (c > 0 && getTileAt(row, c - 1)) c--;
    while (c < SIZE && getTileAt(row, c)) {
        word += getTileAt(row, c)->letter;
        c++;
    }
    return word;
}

std::string Board::collectWordVertical(int row, int col) const {
    std::string word;
    int r = row;
    while (r > 0 && getTileAt(r - 1, col)) r--;
    while (r < SIZE && getTileAt(r, col)) {
        word += getTileAt(r, col)->letter;
        r++;
    }
    return word;
}

// -----------------------------------------------------------------------------
// Lấy "từ hiện tại" dựa trên vị trí quân đầu tiên trong placedTiles
// - Ưu tiên trả về từ ngang nếu độ dài > 1; nếu không thì trả về dọc.
// -----------------------------------------------------------------------------
std::string Board::getCurrentWord(const std::vector<std::pair<int,int>>& placedTiles) const {
    if (placedTiles.empty()) return "";
    int row = placedTiles[0].first;
    int col = placedTiles[0].second;

    std::string horizontal = collectWordHorizontal(row, col);
    std::string vertical   = collectWordVertical(row, col);

    if (horizontal.size() > 1) return horizontal;
    return vertical;
}

// -----------------------------------------------------------------------------
// Getter vùng nút UI
// -----------------------------------------------------------------------------
const SDL_Rect& Board::getResignBtn() const { return resignBtn; }
const SDL_Rect& Board::getSubmitBtn() const { return submitBtn; }
const SDL_Rect& Board::getUndoBtn()  const { return undoBtn;  }
const SDL_Rect& Board::getSwapBtn()  const { return swapBtn;  }
const SDL_Rect& Board::getSkipBtn()  const { return skipBtn;  }
const SDL_Rect& Board::getHintBtn()  const { return hintBtn;  }

// -----------------------------------------------------------------------------
// Truy cập Square theo hàng/cột (để các phần khác có thể thao tác trực tiếp)
// -----------------------------------------------------------------------------
Square& Board::getSquare(int row, int col) { return grid[row][col]; }
