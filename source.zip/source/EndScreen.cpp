#include "EndScreen.h"
#include "Start.h"      // Tái sử dụng hàm vẽ nút từ màn hình Start
#include <iostream>

void showEndScreen(SDL_Renderer* renderer, TTF_Font* font, const std::string& winnerText, int score1, int score2) {
    TTF_Font* bigFont = TTF_OpenFont("C:/Windows/Fonts/arialbd.ttf", 60);
    if (!bigFont) {
        std::cout << "Failed to load bold font, using default." << std::endl;
        bigFont = font;
    }

    // Chuẩn bị các chuỗi văn bản
    std::string scoreText1 = "Player 1: " + std::to_string(score1) + " pts";
    std::string scoreText2 = "Player 2: " + std::to_string(score2) + " pts";

    // Định vị các nút bấm
    int windowWidth, windowHeight;
    SDL_GetRendererOutputSize(renderer, &windowWidth, &windowHeight);
    int startX = (windowWidth-150)/2;

    SDL_Rect playAgainBtn = { startX - 130, 450, 150, 50 };
    SDL_Rect quitBtn = { startX + 130, 450, 150, 50 };

    bool endScreenRunning = true;
    SDL_Event e;

    // Vòng lặp riêng cho màn hình kết thúc
    while (endScreenRunning) {
        // Xử lý sự kiện (nhấn nút, đóng cửa sổ)
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) {
                endScreenRunning = false;
            }
            if (e.type == SDL_MOUSEBUTTONDOWN) {
                int x = e.button.x;
                int y = e.button.y;

                // Nút "Play Again" (hiện tại sẽ thoát game)
                if (x >= playAgainBtn.x && x <= playAgainBtn.x + playAgainBtn.w &&
                    y >= playAgainBtn.y && y <= playAgainBtn.y + playAgainBtn.h) {
                    std::cout << "Play Again chosen. Exiting." << std::endl;
                    endScreenRunning = false;
                }

                // Nút "Quit"
                if (x >= quitBtn.x && x <= quitBtn.x + quitBtn.w &&
                    y >= quitBtn.y && y <= quitBtn.y + quitBtn.h) {
                    std::cout << "Quit chosen. Exiting." << std::endl;
                    endScreenRunning = false;
                }
            }
        }

        // Bắt đầu vẽ màn hình kết thúc
        SDL_SetRenderDrawColor(renderer, 247, 202, 99, 255); //mau nen
        SDL_RenderClear(renderer);

        // Vẽ các thành phần văn bản
        int startX1 = (windowWidth-800)/2;
        drawText(renderer, bigFont, "FINAL", {startX1, 50, 800, 100});
        drawText(renderer, font, winnerText, {startX1, 180, 800, 50});
        drawText(renderer, font, scoreText1, {startX1, 280, 800, 40});
        drawText(renderer, font, scoreText2, {startX1, 330, 800, 40});

        // Vẽ các nút bấm
        drawButton(renderer, font, playAgainBtn, "Play Again");
        drawButton(renderer, font, quitBtn, "Quit");

        // Hiển thị ra màn hình
        SDL_RenderPresent(renderer);
    }

    // Dọn dẹp tài nguyên
    if (bigFont != font) {
        TTF_CloseFont(bigFont);
    }
}
