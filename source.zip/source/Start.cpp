#include "GameLogic.h"
#include <SDL_image.h>
#include <SDL.h>
#include <SDL_ttf.h>
#include <iostream>
#include "Start.h"

using namespace std;

SDL_Texture* loadTexture(const std::string& path, SDL_Renderer* renderer) {
    SDL_Surface* surface = IMG_Load("D:/scrabble9.5/scrabble.jpg");
    if (!surface) {
        std::cerr << "Failed to load image: " << IMG_GetError() << std::endl;
        return nullptr;
    }
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_FreeSurface(surface);
    return texture;
}

void drawText(SDL_Renderer* renderer, TTF_Font* font, const std::string& text, SDL_Rect rect) {
    SDL_Color color = { 0, 0, 0, 255 };
    SDL_Surface* surface = TTF_RenderText_Blended(font, text.c_str(), color);
    if (!surface) return;
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);

    int textW, textH;
    SDL_QueryTexture(texture, NULL, NULL, &textW, &textH);
    SDL_Rect textRect = {
        rect.x + (rect.w - textW) / 2,
        rect.y + (rect.h - textH) / 2,
        textW,
        textH
    };
    SDL_RenderCopy(renderer, texture, NULL, &textRect);
    SDL_FreeSurface(surface);
    SDL_DestroyTexture(texture);
}

void drawButton(SDL_Renderer* renderer, TTF_Font* font, SDL_Rect rect, const std::string& label) {
    SDL_SetRenderDrawColor(renderer, 200, 200, 200, 255);
    SDL_RenderFillRect(renderer, &rect);
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderDrawRect(renderer, &rect);
    drawText(renderer, font, label, rect);
}

// Sửa hàm render để vẽ thêm nút Hướng dẫn
void render(SDL_Renderer* renderer, TTF_Font* font, SDL_Rect playBtn, SDL_Rect exitBtn, SDL_Rect helpBtn) {
    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
    SDL_Texture* background = loadTexture("D:/scrabble9.5/scrabble.jpg", renderer); // Giữ đường dẫn của bạn

    SDL_RenderClear(renderer);

    if (background) {
        SDL_RenderCopy(renderer, background, nullptr, nullptr);
        SDL_DestroyTexture(background);
    }

    drawButton(renderer, font, playBtn, "Play Now");
    drawButton(renderer, font, exitBtn, "Exit");
    drawButton(renderer, font, helpBtn, "Rules"); // Vẽ nút mới

    SDL_RenderPresent(renderer);
}

// Hàm hiển thị màn hình hướng dẫn
void showInstructionsScreen(SDL_Renderer* renderer, TTF_Font* font) {
    SDL_Rect backBtn = { 20, 630, 100, 50 };
    bool inHelpScreen = true;
    SDL_Event e;

    string instructions =
        "Luat Choi Scrabble (Don Gian):\n\n"
        "1. Moi nguoi choi bat dau voi 7 quan co.\n"
        "2. Dat cac quan co len bang de tao thanh tu.\n"
        "3. Tu dau tien phai che o trung tam.\n"
        "4. Cac tu moi phai ket noi voi cac tu da co.\n"
        "5. Tinh diem dua tren cac chu cai va o bonus.\n"
        "6. Su dung het quan co trong mot luot de nhan them diem (Bingo).\n"
        "7. Tro choi ket thuc khi het quan co trong tui va mot nguoi choi het quan co tren tay.\n\n"
        "Nhan 'Back' de quay lai menu chinh.";

    // Tạo một surface lớn hơn cho text
    SDL_Surface* textSurface = TTF_RenderText_Blended_Wrapped(font, instructions.c_str(), {0, 0, 0, 255}, 760);
    SDL_Texture* textTexture = SDL_CreateTextureFromSurface(renderer, textSurface);
    SDL_Rect textRect = { 20, 50, textSurface->w, textSurface->h };
    SDL_FreeSurface(textSurface);

    while (inHelpScreen) {
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) {
                inHelpScreen = false; // Thoát nếu đóng cửa sổ
                exit(0); // Kết thúc chương trình
            }
            if (e.type == SDL_MOUSEBUTTONDOWN) {
                int x = e.button.x, y = e.button.y;
                if (x >= backBtn.x && x <= backBtn.x + backBtn.w &&
                    y >= backBtn.y && y <= backBtn.y + backBtn.h) {
                    inHelpScreen = false; // Quay lại màn hình Welcome
                }
            }
        }

        SDL_SetRenderDrawColor(renderer, 230, 240, 255, 255); // Màu nền khác
        SDL_RenderClear(renderer);

        // Vẽ luật chơi
        SDL_RenderCopy(renderer, textTexture, NULL, &textRect);

        // Vẽ nút Back
        drawButton(renderer, font, backBtn, "Back");

        SDL_RenderPresent(renderer);
    }

    SDL_DestroyTexture(textTexture);
}


// Sửa lại hàm Welcome để quản lý việc chuyển màn hình
void Welcome(SDL_Window* window, SDL_Renderer* renderer, TTF_Font* font) {
    int windowWidth, windowHeight;
    SDL_GetWindowSize(window, &windowWidth, &windowHeight);
    SDL_Rect playBtn = { (windowWidth-150)/2 - 250, 540, 150, 60 };
    SDL_Rect helpBtn = { (windowWidth-150)/2, 540, 150, 60 };
    SDL_Rect exitBtn = {(windowWidth-150)/2 + 250 , 540, 150, 60 };

    SDL_Event e;
    bool quit = false;
    while (!quit) {
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) {
                quit = true;
            }
            if (e.type == SDL_MOUSEBUTTONDOWN) {
                int x = e.button.x, y = e.button.y;

                // Xử lý nút Play
                if (x >= playBtn.x && x <= playBtn.x + playBtn.w &&
                    y >= playBtn.y && y <= playBtn.y + playBtn.h) {
                    cout << "Time to play\n";
                    GameLogic game("config/words.txt");
                    game.run(window, renderer, font);
                    // Sau khi game kết thúc, vòng lặp Welcome sẽ tiếp tục,
                    // hiển thị lại màn hình bắt đầu.
                }

                // Xử lý nút Hướng dẫn
                if (x >= helpBtn.x && x <= helpBtn.x + helpBtn.w &&
                    y >= helpBtn.y && y <= helpBtn.y + helpBtn.h) {
                    showInstructionsScreen(renderer, font);
                    // Sau khi màn hình hướng dẫn đóng, vòng lặp Welcome sẽ vẽ lại màn hình chính.
                }

                // Xử lý nút Exit
                if (x >= exitBtn.x && x <= exitBtn.x + exitBtn.w &&
                    y >= exitBtn.y && y <= exitBtn.y + exitBtn.h) {
                    cout << "Game Over!";
                    quit = true;
                }
            }
        }

        // Vẽ màn hình Welcome
        render(renderer, font, playBtn, exitBtn, helpBtn);
    }
}
