#include "Tile.h"

Tile::Tile(char l, int p) : letter(l), points(p) {}

Tile::Tile() : letter(' '), points(0) {}



