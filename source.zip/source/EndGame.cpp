#include "EndGame.h"
#include "EndScreen.h"
#include "GameLogic.h"
#include "Board.h"
#include <iostream>

void showEndGame(Board& board,const std::string& winnerText, int score1, int score2, bool& running) {
    SDL_Renderer* renderer = board.getRenderer();
    TTF_Font* font = board.getFont();

    int windowWidth, windowHeight;
    SDL_GetRendererOutputSize(renderer, &windowWidth, &windowHeight);
    SDL_Rect popupRect = {(windowWidth-400)/2, (windowHeight-200)/2, 400, 200};
    SDL_Rect buttonRect  = {popupRect.x + 50,  popupRect.y + 120, 80, 35}; // Yes
    SDL_Rect buttonRect1 = {popupRect.x + 270, popupRect.y + 120, 80, 35}; // No

    SDL_Color buttonColor = {200, 200, 200, 255};
    SDL_Color textColor   = {0, 0, 0, 255};
    SDL_Color red         = {255, 0, 0, 255};

    bool quit = false;
    SDL_Event e;
    while (!quit) {
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) {
                    quit = true;
                    running = false;
            }
            if (e.type == SDL_MOUSEBUTTONDOWN) {
                int x = e.button.x, y = e.button.y;
                // Yes
                if (x >= buttonRect.x && x <= buttonRect.x + buttonRect.w &&
                    y >= buttonRect.y && y <= buttonRect.y + buttonRect.h) {
                    cout<<"Game Over!"<<endl;
                    quit = true;
                    running = false;
                    showEndScreen(renderer, font, winnerText, score1, score2);
                }
                // No
                if (x >= buttonRect1.x && x <= buttonRect1.x + buttonRect1.w &&
                    y >= buttonRect1.y && y <= buttonRect1.y + buttonRect1.h) {
                    cout<<"The game continues."<<endl;
                    quit = true;
                    return;
                }
            }
        }

        // Vẽ nền mờ
        SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 128);
        SDL_RenderFillRect(renderer, NULL);

        // Vẽ popup trắng
        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        SDL_RenderFillRect(renderer, &popupRect);

        // Vẽ text "Do you want to exit?"
        SDL_Surface* textSurface = TTF_RenderText_Solid(font, "Do you want to exit?", red);
        SDL_Texture* textTexture = SDL_CreateTextureFromSurface(renderer, textSurface);
        SDL_Rect textRect = {popupRect.x + (popupRect.w - textSurface->w) / 2,
                             popupRect.y + 50, textSurface->w, textSurface->h};
        SDL_FreeSurface(textSurface);
        SDL_RenderCopy(renderer, textTexture, NULL, &textRect);
        SDL_DestroyTexture(textTexture);

        // Vẽ nút Yes
        SDL_SetRenderDrawColor(renderer, buttonColor.r, buttonColor.g, buttonColor.b, buttonColor.a);
        SDL_RenderFillRect(renderer, &buttonRect);
        SDL_Surface* yesSurf = TTF_RenderText_Blended(font, "Yes", textColor);
        SDL_Texture* yesTex  = SDL_CreateTextureFromSurface(renderer, yesSurf);
        SDL_Rect yesTxtRect  = {buttonRect.x + (buttonRect.w - yesSurf->w) / 2,
                                buttonRect.y + (buttonRect.h - yesSurf->h) / 2,
                                yesSurf->w, yesSurf->h};
        SDL_FreeSurface(yesSurf);
        SDL_RenderCopy(renderer, yesTex, NULL, &yesTxtRect);
        SDL_DestroyTexture(yesTex);

        // Vẽ nút No
        SDL_SetRenderDrawColor(renderer, buttonColor.r, buttonColor.g, buttonColor.b, buttonColor.a);
        SDL_RenderFillRect(renderer, &buttonRect1);
        SDL_Surface* noSurf = TTF_RenderText_Blended(font, "No", textColor);
        SDL_Texture* noTex  = SDL_CreateTextureFromSurface(renderer, noSurf);
        SDL_Rect noTxtRect  = {buttonRect1.x + (buttonRect1.w - noSurf->w) / 2,
                               buttonRect1.y + (buttonRect1.h - noSurf->h) / 2,
                               noSurf->w, noSurf->h};
        SDL_FreeSurface(noSurf);
        SDL_RenderCopy(renderer, noTex, NULL, &noTxtRect);
        SDL_DestroyTexture(noTex);

        SDL_RenderPresent(renderer);
    }
}
