// ============================================================================
// GameLogic.cpp
// Mục tiêu:
//  - Quản lý lượt chơi, thời gian mỗi người, thao tác kéo/thả chữ, xác nhận từ.
//  - Render panel thông tin, lịch sử từ, gợi ý (hint), và khay chữ.
//  - Thuật toán gợi ý: backtracking + cắt tỉa (branch & bound) + greedy dừng sớm.
// Lưu ý:
//  - Không thay đổi logic cốt lõi, chỉ format và bổ sung comment tiếng Việt.
//  - Cần các header: EndGame.h, GameLogic.h, EndScreen.h, SDL, SDL_ttf, v.v.
// ============================================================================

constexpr int GREEDY_STOP_THRESHOLD = 30;

#include "EndGame.h"
#include "GameLogic.h"
#include "EndScreen.h"

#include <SDL.h>
#include <SDL_ttf.h>

#include <algorithm>
#include <functional>
#include <iomanip>
#include <iostream>
#include <random>
#include <sstream>
#include <vector>

using namespace std;

// -----------------------------------------------------------------------------
// formatTime
// Chuyển giây (float) -> chuỗi "mm:ss", bảo vệ âm -> 00:00
// -----------------------------------------------------------------------------
string GameLogic::formatTime(float seconds) {
    if (seconds < 0) seconds = 0;
    int totalSeconds = static_cast<int>(seconds);
    int minutes = totalSeconds / 60;
    int secs = totalSeconds % 60;

    std::stringstream ss;
    ss << std::setw(2) << std::setfill('0') << minutes << ":"
       << std::setw(2) << std::setfill('0') << secs;
    return ss.str();
}

// -----------------------------------------------------------------------------
// GameLogic ctor
// - Tạo 2 người chơi mặc định, rút quân ban đầu từ túi
// - currentPlayer = player1; reset mốc thời gian lượt
// -----------------------------------------------------------------------------
GameLogic::GameLogic(const string& dictFile)
    : dict(dictFile), player1("Player 1"), player2("Player 2") {
    currentPlayer = &player1;
    player1.drawTiles(bag);
    player2.drawTiles(bag);
    turnStartTime = 0;
}

// -----------------------------------------------------------------------------
// switchToNextPlayer
// - Ghi nhận thời gian đã dùng cho người chơi hiện tại
// - Chuyển lượt, reset mốc thời gian, xóa gợi ý
// -----------------------------------------------------------------------------
void GameLogic::switchToNextPlayer() {
    float timeSpent = (SDL_GetTicks() - turnStartTime) / 1000.0f;
    currentPlayer->decreaseTime(timeSpent);

    currentPlayer = (currentPlayer == &player1) ? &player2 : &player1;
    turnStartTime = SDL_GetTicks();

    cout << "\nNow is " << currentPlayer->getName() << "'s turn." << endl;
    hintSuggestion.clear();
}

// -----------------------------------------------------------------------------
// findHint  (Thuật toán gợi ý từ vựng từ bộ chữ đang có)
// - Biến quân đang có thành chuỗi ký tự in hoa
// - Sắp xếp giảm dần theo điểm chữ cái để greedy thử trước
// - Backtracking xây dựng chuỗi; kiểm tra:
//      + Nếu current là từ hợp lệ -> cập nhật best (điểm cao nhất)
//      + Ước lượng điểm tối đa có thể thêm (remainingMax), nếu
//        currentScore + remainingMax <= bestScore => cắt nhánh
// - Dừng sớm nếu bestScore >= GREEDY_STOP_THRESHOLD (đủ tốt)
// -----------------------------------------------------------------------------
void GameLogic::findHint() {
    const auto& hand = currentPlayer->getHand();
    if (hand.empty()) {
        hintSuggestion = "Khong co goi y.";
        return;
    }

    // Gom chữ cái trên tay -> string (in hoa)
    string handLetters;
    for (const auto& tile : hand) handLetters.push_back(toupper(tile.letter));

    // Greedy: thử chữ có điểm cao trước để nhanh đạt ngưỡng dừng
    sort(handLetters.begin(), handLetters.end(), [&](char a, char b) {
        return getLetterScore(a) > getLetterScore(b);
    });

    vector<bool> used(handLetters.size(), false);
    string current;
    string bestHint;
    int bestScore = -1;

    function<void(int)> backtrack = [&](int currentScore) {
        // Nếu chuỗi hiện tại là từ hợp lệ (độ dài >= 2), cập nhật best
        if (current.size() >= 2 && dict.isValidWord(current)) {
            if (currentScore > bestScore) {
                bestScore = currentScore;
                bestHint = current;

                // Dừng sớm nếu đạt ngưỡng "đủ tốt"
                if (bestScore >= GREEDY_STOP_THRESHOLD) return;
            }
        }

        // Ước lượng trần điểm còn lại để cắt tỉa nhanh
        int remainingMax = 0;
        for (size_t i = 0; i < handLetters.size(); i++) {
            if (!used[i]) remainingMax += getLetterScore(handLetters[i]);
        }
        if (currentScore + remainingMax <= bestScore) return; // cắt nhánh

        // Thử ghép tiếp nếu prefix còn hợp lệ trong từ điển
        for (size_t i = 0; i < handLetters.size(); i++) {
            if (used[i]) continue;

            char c = handLetters[i];
            current.push_back(c);

            if (dict.startsWith(current)) { // chỉ tiếp tục nếu là tiền tố hợp lệ
                used[i] = true;
                backtrack(currentScore + getLetterScore(c));
                used[i] = false;
            }

            current.pop_back();
        }
    };

    backtrack(0);

    if (!bestHint.empty()) {
        hintSuggestion = "Goi y tu vung: '" + bestHint + "' (" + to_string(bestScore) + " diem)";
    } else {
        hintSuggestion = "Khong tim thay tu hop le.";
    }
}

// -----------------------------------------------------------------------------
// getLetterScore
// - Bảng điểm tương tự Scrabble (tiếng Anh). Trả 0 nếu ký tự lạ.
// -----------------------------------------------------------------------------
int GameLogic::getLetterScore(char letter) const {
    letter = toupper(letter);
    switch (letter) {
        case 'A': case 'E': case 'I': case 'O': case 'U':
        case 'L': case 'N': case 'S': case 'T': case 'R':
            return 1;
        case 'D': case 'G':
            return 2;
        case 'B': case 'C': case 'M': case 'P':
            return 3;
        case 'F': case 'H': case 'V': case 'W': case 'Y':
            return 4;
        case 'K':
            return 5;
        case 'J': case 'X':
            return 8;
        case 'Q': case 'Z':
            return 10;
        default:
            return 0;
    }
}

// ============================================================================
// run
// Vòng đời trận đấu:
//  1) Khởi tạo board, lấy kích thước render target
//  2) Vòng lặp chính:
//     - Kiểm tra hết giờ của người chơi hiện tại -> skip lượt (hoàn trả quân đặt)
//     - Xử lý sự kiện SDL: quit, chuột, phím, nút UI (submit/undo/skip/resign/swap/hint)
//     - Render: bàn cờ, panel phải (điểm + thời gian), lịch sử từ, gợi ý, khay chữ
//  3) Khi kết thúc: xác định người thắng và hiện EndScreen
// Ghi chú:
//  - `placedTiles` lưu các ô (row,col) đang đặt trong lượt để undo/commit.
//  - Kéo chữ: bắt bằng click trái vào khay; thả lên ô trống sẽ placeTile & removeTile.
//  - Nút/Phím tắt: Enter=submit, Backspace=undo; Skip/Resign/Swap/Hint qua hit-test nút.
// ============================================================================
void GameLogic::run(SDL_Window* window, SDL_Renderer* renderer, TTF_Font* font) {
    bool running = true;
    SDL_Event e;

    int screenWidth, screenHeight;
    SDL_GetRendererOutputSize(renderer, &screenWidth, &screenHeight);

    board.init(renderer, font);

    Tile* draggedTile = nullptr; // con trỏ tới quân đang kéo (nếu có)
    turnStartTime = SDL_GetTicks();

    while (running && !isGameOver()) {
        // ---- Quản lý thời gian lượt hiện tại
        float timeElapsedThisTurn = (SDL_GetTicks() - turnStartTime) / 1000.0f;
        if (currentPlayer->getTimeRemaining() - timeElapsedThisTurn <= 0) {
            // Hết giờ -> skip: hoàn trả quân đã đặt & chuyển lượt
            cout << currentPlayer->getName() << "'s time is up! Turn skipped." << endl;
            for (auto& pos : placedTiles) {
                if (board.getTileAt(pos.first, pos.second)) {
                    currentPlayer->returnTile(*board.getTileAt(pos.first, pos.second));
                    board.removeTileAt(pos.first, pos.second);
                }
            }
            placedTiles.clear();
            board.clearUndo();
            switchToNextPlayer();
            continue;
        }

        // ---- Xử lý sự kiện
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) running = false;
            if (currentPlayer->getTimeRemaining() <= 0) continue; // nếu đã hết giờ thì không cho thao tác

            board.handleEvent(e); // chuyển sự kiện chung xuống board nếu cần

            // --- Chuột xuống: thử bắt quân ở khay, đồng thời xử lý click vào nút UI
            if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT) {
                int mx = e.button.x, my = e.button.y;

                // Tính toán vị trí panel bên phải + khay chữ linh hoạt theo kích cỡ màn hình
                int rightPanelX = BOARD_OFFSET_X + BOARD_WIDTH_PIXELS + 50;
                int buttonAreaY = screenHeight - 180;      // Y của dải nút (ở dưới)
                int rackX = rightPanelX;
                int rackY = buttonAreaY - TILE_SIZE - 30;  // khay chữ đặt phía trên nút, cách 30px

                // Hit-test các chữ cái trên khay để bắt kéo
                for (size_t i = 0; i < currentPlayer->getHand().size(); ++i) {
                    SDL_Rect rect = { rackX + int(i) * (TILE_SIZE + 5), rackY, TILE_SIZE, TILE_SIZE };
                    if (mx >= rect.x && mx <= rect.x + TILE_SIZE && my >= rect.y && my <= rect.y + TILE_SIZE) {
                        draggedTile = &currentPlayer->getHand()[i];
                        break;
                    }
                }

                // Hit-test các nút chức năng
                SDL_Point clickPoint = { mx, my };
                if (SDL_PointInRect(&clickPoint, &board.getSubmitBtn())) {
                    // Xác nhận từ (commit)
                    confirmWord();
                } else if (SDL_PointInRect(&clickPoint, &board.getUndoBtn())) {
                    // Hoàn tác 1 bước đặt chữ gần nhất
                    if (board.undo(*currentPlayer)) {
                        if (!placedTiles.empty()) {
                            placedTiles.pop_back();
                            cout << "Undo success!\n";
                        }
                    } else {
                        cout << "Nothing to undo!\n";
                    }
                } else if (SDL_PointInRect(&clickPoint, &board.getSkipBtn())) {
                    // Bỏ lượt: hoàn trả toàn bộ quân vừa đặt, chuyển lượt
                    cout << currentPlayer->getName() << " skipped the turn.\n";
                    for (auto& pos : placedTiles) {
                        if (board.getTileAt(pos.first, pos.second)) {
                            currentPlayer->returnTile(*board.getTileAt(pos.first, pos.second));
                            board.removeTileAt(pos.first, pos.second);
                        }
                    }
                    placedTiles.clear();
                    board.clearUndo();
                    switchToNextPlayer();
                } else if (SDL_PointInRect(&clickPoint, &board.getResignBtn())) {
                    // Đầu hàng: xác định người thắng theo điểm hiện tại, hiển thị EndGame
                    cout << currentPlayer->getName() << " resigned!\n";
                    string winnerText;
                    if (player1.getScore() > player2.getScore()) {
                        winnerText = player1.getName() + " Wins!";
                    } else if (player2.getScore() > player1.getScore()) {
                        winnerText = player2.getName() + " Wins!";
                    } else {
                        winnerText = "It's a Tie!";
                    }
                    showEndGame(board, winnerText, player1.getScore(), player2.getScore(), running);
                } else if (SDL_PointInRect(&clickPoint, &board.getSwapBtn())) {
                    // Đổi vị trí (shuffle) quân trong tay (random)
                    std::random_device rd;
                    std::mt19937 g(rd());
                    std::shuffle(currentPlayer->getHand().begin(), currentPlayer->getHand().end(), g);
                    cout << currentPlayer->getName() << " shuffled tiles.\n";
                } else if (SDL_PointInRect(&clickPoint, &board.getHintBtn())) {
                    // Gợi ý từ vựng dựa trên quân hiện có
                    cout << "Hint button clicked!\n";
                    findHint();
                }
            }

            // --- Chuột nhả: nếu đang kéo quân -> thử đặt lên ô trống hợp lệ
            if (e.type == SDL_MOUSEBUTTONUP && draggedTile) {
                int bx = (e.button.x - BOARD_OFFSET_X) / TILE_SIZE;
                int by = (e.button.y - BOARD_OFFSET_Y) / TILE_SIZE;

                if (bx >= 0 && bx < BOARD_SIZE && by >= 0 && by < BOARD_SIZE && board.isEmpty(by, bx)) {
                    board.placeTile(by, bx, *draggedTile);
                    placedTiles.push_back({ by, bx });
                    currentPlayer->removeTile(draggedTile->letter);
                }
                draggedTile = nullptr;
            }

            // --- Phím tắt: Enter=submit; Backspace=undo
            if (e.type == SDL_KEYDOWN) {
                if (e.key.keysym.sym == SDLK_RETURN) {
                    confirmWord();
                }
                if (e.key.keysym.sym == SDLK_BACKSPACE) {
                    if (board.undo(*currentPlayer)) {
                        if (!placedTiles.empty()) placedTiles.pop_back();
                        cout << "Undo success!\n";
                    } else {
                        cout << "Nothing to undo!\n";
                    }
                }
            }
        }

        // ---- Vẽ khung nền
        SDL_SetRenderDrawColor(renderer, 20, 40, 50, 255);
        SDL_RenderClear(renderer);

        // ---- Vẽ bàn cờ và các quân đã đặt trong lượt
        board.render(renderer, placedTiles);

        // ---- Panel phải (điểm & thời gian 2 người)
        int rightPanelX = BOARD_OFFSET_X + BOARD_WIDTH_PIXELS + 50;
        SDL_Color textColor = { 220, 220, 220, 255 };

        int p1_info_y = 80;

        // Người chơi 1
        string p1_scoreText = player1.getName() + ": " + to_string(player1.getScore()) + " pts";
        float p1_displayTime = (currentPlayer == &player1)
            ? player1.getTimeRemaining() - timeElapsedThisTurn
            : player1.getTimeRemaining();
        string p1_timeText = "Time: " + formatTime(p1_displayTime);

        SDL_Surface* p1_scoreSurface = TTF_RenderText_Solid(font, p1_scoreText.c_str(), textColor);
        SDL_Texture* p1_scoreTexture = SDL_CreateTextureFromSurface(renderer, p1_scoreSurface);
        SDL_Rect p1_scoreRect = { rightPanelX, p1_info_y, p1_scoreSurface->w, p1_scoreSurface->h };
        SDL_RenderCopy(renderer, p1_scoreTexture, NULL, &p1_scoreRect);

        SDL_Surface* p1_timeSurface = TTF_RenderText_Solid(font, p1_timeText.c_str(), textColor);
        SDL_Texture* p1_timeTexture = SDL_CreateTextureFromSurface(renderer, p1_timeSurface);
        SDL_Rect p1_timeRect = { rightPanelX, p1_info_y + 25, p1_timeSurface->w, p1_timeSurface->h };
        SDL_RenderCopy(renderer, p1_timeTexture, NULL, &p1_timeRect);

        // Người chơi 2
        string p2_scoreText = player2.getName() + ": " + to_string(player2.getScore()) + " pts";
        float p2_displayTime = (currentPlayer == &player2)
            ? player2.getTimeRemaining() - timeElapsedThisTurn
            : player2.getTimeRemaining();
        string p2_timeText = "Time: " + formatTime(p2_displayTime);

        SDL_Surface* p2_scoreSurface = TTF_RenderText_Solid(font, p2_scoreText.c_str(), textColor);
        SDL_Texture* p2_scoreTexture = SDL_CreateTextureFromSurface(renderer, p2_scoreSurface);
        SDL_Rect p2_scoreRect = { rightPanelX + 300, p1_info_y, p2_scoreSurface->w, p2_scoreSurface->h };
        SDL_RenderCopy(renderer, p2_scoreTexture, NULL, &p2_scoreRect);

        SDL_Surface* p2_timeSurface = TTF_RenderText_Solid(font, p2_timeText.c_str(), textColor);
        SDL_Texture* p2_timeTexture = SDL_CreateTextureFromSurface(renderer, p2_timeSurface);
        SDL_Rect p2_timeRect = { rightPanelX + 300, p1_info_y + 25, p2_timeSurface->w, p2_timeSurface->h };
        SDL_RenderCopy(renderer, p2_timeTexture, NULL, &p2_timeRect);

        // Giải phóng surface/texture tạm
        SDL_FreeSurface(p1_scoreSurface); SDL_DestroyTexture(p1_scoreTexture);
        SDL_FreeSurface(p1_timeSurface);  SDL_DestroyTexture(p1_timeTexture);
        SDL_FreeSurface(p2_scoreSurface); SDL_DestroyTexture(p2_scoreTexture);
        SDL_FreeSurface(p2_timeSurface);  SDL_DestroyTexture(p2_timeTexture);

        // ---- Hiển thị từ vừa đặt (Last/Prev)
        int words_y_start = 250;
        for (size_t i = 0; i < lastWords.size(); ++i) {
            string label = (i == 0 ? "Last: " : "Prev: ") + lastWords[i];
            SDL_Color wordColor = (i == 0)
                ? SDL_Color{ 255, 100, 100, 255 }
                : SDL_Color{ 200, 200, 200, 255 };
            SDL_Surface* surf = TTF_RenderText_Solid(font, label.c_str(), wordColor);
            SDL_Texture* tex = SDL_CreateTextureFromSurface(renderer, surf);
            SDL_Rect dst = { rightPanelX, words_y_start + int(i) * 30, surf->w, surf->h };
            SDL_RenderCopy(renderer, tex, NULL, &dst);
            SDL_FreeSurface(surf); SDL_DestroyTexture(tex);
        }

        // ---- Gợi ý (nếu có)
        if (!hintSuggestion.empty()) {
            SDL_Color hintColor = { 100, 255, 100, 255 };
            SDL_Surface* hintSurf = TTF_RenderText_Blended_Wrapped(
                font, hintSuggestion.c_str(), hintColor, screenWidth - rightPanelX - 20
            );
            if (hintSurf) {
                SDL_Texture* hintTex = SDL_CreateTextureFromSurface(renderer, hintSurf);
                SDL_Rect hintDstRect = { rightPanelX, words_y_start + 100, hintSurf->w, hintSurf->h };
                SDL_RenderCopy(renderer, hintTex, NULL, &hintDstRect);
                SDL_FreeSurface(hintSurf);
                SDL_DestroyTexture(hintTex);
            }
        }

        // ---- Vẽ khay chữ (vị trí mới, ngay trên dải nút)
        int buttonAreaY = screenHeight - 180;
        int rackX = rightPanelX;
        int rackY = buttonAreaY - TILE_SIZE - 30;

        if (currentPlayer->getTimeRemaining() > 0) {
            for (size_t i = 0; i < currentPlayer->getHand().size(); ++i) {
                SDL_Rect rect = { rackX + int(i) * (TILE_SIZE + 5), rackY, TILE_SIZE, TILE_SIZE };

                // Nền ô chữ
                SDL_SetRenderDrawColor(renderer, 255, 228, 181, 255);
                SDL_RenderFillRect(renderer, &rect);

                // Viền ô
                SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
                SDL_RenderDrawRect(renderer, &rect);

                // Vẽ ký tự: ưu tiên texture chữ pre-render sẵn từ board
                char ch = currentPlayer->getHand()[i].letter;
                SDL_Texture* letterTex = board.getLetterTexture(ch);
                if (letterTex) {
                    SDL_Rect dst = { rect.x + 2, rect.y + 2, rect.w - 4, rect.h - 4 };
                    SDL_RenderCopy(renderer, letterTex, NULL, &dst);
                } else {
                    // Fallback: render chữ tức thời
                    std::string letter(1, ch);
                    SDL_Color color = { 0, 0, 0, 255 };
                    SDL_Surface* surf = TTF_RenderText_Solid(font, letter.c_str(), color);
                    if (surf) {
                        SDL_Texture* tex = SDL_CreateTextureFromSurface(renderer, surf);
                        int w, h; SDL_QueryTexture(tex, NULL, NULL, &w, &h);
                        SDL_Rect dst = { rect.x + (TILE_SIZE - w) / 2, rect.y + (TILE_SIZE - h) / 2, w, h };
                        SDL_RenderCopy(renderer, tex, NULL, &dst);
                        SDL_FreeSurface(surf); SDL_DestroyTexture(tex);
                    }
                }
            }
        }

        // ---- Swap buffer
        SDL_RenderPresent(renderer);
    }

    // ---- Thoát vòng chơi nhưng chưa SDL_QUIT: hiện màn kết thúc
    if (running) {
        string winnerText;
        if (player1.getScore() > player2.getScore()) {
            winnerText = player1.getName() + " Wins!";
        } else if (player2.getScore() > player1.getScore()) {
            winnerText = player2.getName() + " Wins!";
        } else {
            winnerText = "It's a Tie!";
        }
        cout << "Game Over Final Score: "
             << player1.getName() << " " << player1.getScore()
             << " - " << player2.getScore() << " " << player2.getName() << endl;

        showEndScreen(renderer, font, winnerText, player1.getScore(), player2.getScore());
    }
}

// -----------------------------------------------------------------------------
// confirmWord
// - Lấy từ hiện tại từ các ô vừa đặt -> commit:
//      * Nếu invalid (score < 0) -> báo lỗi
//      * Nếu hợp lệ -> push vào lịch sử (tối đa 5), xóa mark đang đặt
//      * nextTurn()
// -----------------------------------------------------------------------------
bool GameLogic::confirmWord() {
    string word = board.getCurrentWord(placedTiles);
    int score = board.commitWord(placedTiles, *currentPlayer, dict);

    if (score < 0) {
        cout << "Invalid move!\n";
        return false;
    }

    if (!word.empty()) {
        lastWords.push_front(word);
        if (lastWords.size() > 5) lastWords.pop_back();
    }

    placedTiles.clear();
    board.clearUndo();

    cout << currentPlayer->getName() << " scored " << score
         << " points for the word '" << word << "'!\n";

    nextTurn();
    return true;
}

// -----------------------------------------------------------------------------
// nextTurn
// - Bốc bù quân cho người chơi hiện tại, sau đó chuyển lượt
// -----------------------------------------------------------------------------
void GameLogic::nextTurn() {
    currentPlayer->drawTiles(bag);
    switchToNextPlayer();
}

// -----------------------------------------------------------------------------
// isGameOver
// - Kết thúc khi:
//    * Cả 2 đều hết thời gian, hoặc
//    * Túi trống và (ít nhất 1 người) đã hết quân trên tay
// -----------------------------------------------------------------------------
bool GameLogic::isGameOver() {
    if (player1.getTimeRemaining() <= 0 && player2.getTimeRemaining() <= 0) {
        cout << "Game Over! Both players ran out of time." << endl;
        return true;
    }
    return bag.isEmpty() && (player1.getHand().empty() || player2.getHand().empty());
}
