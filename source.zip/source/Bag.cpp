
#include "Bag.h"
#include <algorithm>
#pragma once



Bag::Bag() {
    string letters = "EEEEEEEEEEEEAAAAAAAAAIIIIIIIIOOOOOOOONNNNNNRRRRRRTTTTTTLLLLSSSSUUUUDDDDGGGBBCCMMPPFFHHVVWWYYKJXQZ";
    int pointsTable[26] = {
        1, 3, 3, 2, 1, 4, 2, 4, 1, 8, 5, 1, 3,
        1, 1, 3,10, 1, 1, 1, 1, 4, 4, 8, 4,10
    };
    for (char c : letters) {
        tiles.push_back(Tile(c, pointsTable[c - 'A']));
    }
    random_device rd;
    mt19937 g(rd());
    shuffle(tiles.begin(), tiles.end(), g);
}

Tile Bag::drawTile() {
    if (!tiles.empty()) {
        Tile t = tiles.back();
        tiles.pop_back();
        return t;
    }
    return Tile();
}

void Bag::putBackTile(Tile tile) {
    tiles.push_back(tile);
}

bool Bag::isEmpty() const {
    return tiles.empty();
}
